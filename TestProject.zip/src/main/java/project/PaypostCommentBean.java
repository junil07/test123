package project;

public class PaypostCommentBean {
	private int paypost_comment_num;
	private int comment_paypost_num;
	private String paypost_comment_content;
	private int paypost_comment_reply_pos;
	private int paypost_comment_reply_ref;
	private int paypost_comment_reply_depth;
	private String paypost_comment_user_id;
	private String paypost_comment_date;
	
	
	public int getPaypost_comment_num() {
		return paypost_comment_num;
	}
	public void setPaypost_comment_num(int paypost_comment_num) {
		this.paypost_comment_num = paypost_comment_num;
	}
	public int getComment_paypost_num() {
		return comment_paypost_num;
	}
	public void setComment_paypost_num(int comment_paypost_num) {
		this.comment_paypost_num = comment_paypost_num;
	}
	public String getPaypost_comment_content() {
		return paypost_comment_content;
	}
	public void setPaypost_comment_content(String paypost_comment_content) {
		this.paypost_comment_content = paypost_comment_content;
	}
	public int getPaypost_comment_reply_pos() {
		return paypost_comment_reply_pos;
	}
	public void setPaypost_comment_reply_pos(int paypost_comment_reply_pos) {
		this.paypost_comment_reply_pos = paypost_comment_reply_pos;
	}
	public int getPaypost_comment_reply_ref() {
		return paypost_comment_reply_ref;
	}
	public void setPaypost_comment_reply_ref(int paypost_comment_reply_ref) {
		this.paypost_comment_reply_ref = paypost_comment_reply_ref;
	}
	public int getPaypost_comment_reply_depth() {
		return paypost_comment_reply_depth;
	}
	public void setPaypost_comment_reply_depth(int paypost_comment_reply_depth) {
		this.paypost_comment_reply_depth = paypost_comment_reply_depth;
	}
	public String getPaypost_comment_user_id() {
		return paypost_comment_user_id;
	}
	public void setPaypost_comment_user_id(String paypost_comment_user_id) {
		this.paypost_comment_user_id = paypost_comment_user_id;
	}
	public String getPaypost_comment_date() {
		return paypost_comment_date;
	}
	public void setPaypost_comment_date(String paypost_comment_date) {
		this.paypost_comment_date = paypost_comment_date;
	}
}
