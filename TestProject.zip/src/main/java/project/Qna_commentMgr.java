package project;

public class Qna_commentMgr {
	
	private DBConnectionMgr pool;
	
	public Qna_commentMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
}
