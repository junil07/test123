package project;

public class TesthisBean {
	private int testhis_num;
	private int testhis_choice_num;
	private String testhis_user_id;
	private String testhis_correct;
	private String testhis_date;
	public int getTesthis_num() {
		return testhis_num;
	}
	public void setTesthis_num(int testhis_num) {
		this.testhis_num = testhis_num;
	}
	public int getTesthis_choice_num() {
		return testhis_choice_num;
	}
	public void setTesthis_choice_num(int testhis_choice_num) {
		this.testhis_choice_num = testhis_choice_num;
	}
	public String getTesthis_user_id() {
		return testhis_user_id;
	}
	public void setTesthis_user_id(String testhis_user_id) {
		this.testhis_user_id = testhis_user_id;
	}
	public String getTesthis_correct() {
		return testhis_correct;
	}
	public void setTesthis_correct(String testhis_correct) {
		this.testhis_correct = testhis_correct;
	}
	public String getTesthis_date() {
		return testhis_date;
	}
	public void setTesthis_date(String testhis_date) {
		this.testhis_date = testhis_date;
	}
}
