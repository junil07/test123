package project;

public class ChoiceMgr {
	
	private DBConnectionMgr pool;
	
	public ChoiceMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	
	
}
