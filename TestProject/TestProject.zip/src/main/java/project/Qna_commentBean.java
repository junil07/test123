package project;

public class Qna_commentBean {
	private int qna_comment_num;
	private int comment_qna_num;
	private String qna_comment_content;
	private int qna_comment_reply_pos;
	private int qna_comment_reply_ref;
	private int qna_comment_reply_depth;
	private String  qna_comment_user_id;
	private String qna_comment_date;
	
	public int getQna_comment_num() {
		return qna_comment_num;
	}
	public void setQna_comment_num(int qna_comment_num) {
		this.qna_comment_num = qna_comment_num;
	}
	public int getComment_qna_num() {
		return comment_qna_num;
	}
	public void setComment_qna_num(int comment_qna_num) {
		this.comment_qna_num = comment_qna_num;
	}
	public String getQna_comment_content() {
		return qna_comment_content;
	}
	public void setQna_comment_content(String qna_comment_content) {
		this.qna_comment_content = qna_comment_content;
	}
	public int getQna_comment_reply_pos() {
		return qna_comment_reply_pos;
	}
	public void setQna_comment_reply_pos(int qna_comment_reply_pos) {
		this.qna_comment_reply_pos = qna_comment_reply_pos;
	}
	public int getQna_comment_reply_ref() {
		return qna_comment_reply_ref;
	}
	public void setQna_comment_reply_ref(int qna_comment_reply_ref) {
		this.qna_comment_reply_ref = qna_comment_reply_ref;
	}
	public int getQna_comment_reply_depth() {
		return qna_comment_reply_depth;
	}
	public void setQna_comment_reply_depth(int qna_comment_reply_depth) {
		this.qna_comment_reply_depth = qna_comment_reply_depth;
	}
	public String getQna_comment_user_id() {
		return qna_comment_user_id;
	}
	public void setQna_comment_user_id(String qna_comment_user_id) {
		this.qna_comment_user_id = qna_comment_user_id;
	}
	public String getQna_comment_date() {
		return qna_comment_date;
	}
	public void setQna_comment_date(String qna_comment_date) {
		this.qna_comment_date = qna_comment_date;
	}
}
