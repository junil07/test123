package project;

public class PaypostBean {
	private int paypost_num;
	private String paypost_test_num;
	private String paypost_user_id;
	private String paypost_title;
	private String paypost_content;
	private int paypost_pay;
	private int paypost_agree;
	private String paypost_date;
	private int paypost_good;
	private String paypost_reason;
	
	
	public int getPaypost_num() {
		return paypost_num;
	}
	public void setPaypost_num(int paypost_num) {
		this.paypost_num = paypost_num;
	}
	public String getPaypost_test_num() {
		return paypost_test_num;
	}
	public void setPaypost_test_num(String paypost_test_num) {
		this.paypost_test_num = paypost_test_num;
	}
	public String getPaypost_user_id() {
		return paypost_user_id;
	}
	public void setPaypost_user_id(String paypost_user_id) {
		this.paypost_user_id = paypost_user_id;
	}
	public String getPaypost_title() {
		return paypost_title;
	}
	public void setPaypost_title(String paypost_title) {
		this.paypost_title = paypost_title;
	}
	public String getPaypost_content() {
		return paypost_content;
	}
	public void setPaypost_content(String paypost_content) {
		this.paypost_content = paypost_content;
	}
	public int getPaypost_pay() {
		return paypost_pay;
	}
	public void setPaypost_pay(int paypost_pay) {
		this.paypost_pay = paypost_pay;
	}
	public int getPaypost_agree() {
		return paypost_agree;
	}
	public void setPaypost_agree(int paypost_agree) {
		this.paypost_agree = paypost_agree;
	}
	public String getPaypost_date() {
		return paypost_date;
	}
	public void setPaypost_date(String paypost_date) {
		this.paypost_date = paypost_date;
	}
	public int getPaypost_good() {
		return paypost_good;
	}
	public void setPaypost_good(int paypost_good) {
		this.paypost_good = paypost_good;
	}
	public String getPaypost_reason() {
		return paypost_reason;
	}
	public void setPaypost_reason(String paypost_reason) {
		this.paypost_reason = paypost_reason;
	}
}
