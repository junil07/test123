package project;

public class QnaMgr {

}
