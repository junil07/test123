package project;

public class TestBean {
	private String test_num;
	private String test_title;
	private String test_year;
	private int test_session;
	private String test_subject;
	public String getTest_num() {
		return test_num;
	}
	public void setTest_num(String test_num) {
		this.test_num = test_num;
	}
	public String getTest_title() {
		return test_title;
	}
	public void setTest_title(String test_title) {
		this.test_title = test_title;
	}
	public String getTest_year() {
		return test_year;
	}
	public void setTest_year(String test_year) {
		this.test_year = test_year;
	}
	public int getTest_session() {
		return test_session;
	}
	public void setTest_session(int test_session) {
		this.test_session = test_session;
	}
	public String getTest_subject() {
		return test_subject;
	}
	public void setTest_subject(String test_subject) {
		this.test_subject = test_subject;
	}
}
