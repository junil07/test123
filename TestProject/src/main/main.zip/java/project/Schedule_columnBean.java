package project;

public class Schedule_columnBean {
	
	private int schedule_column_num;
	private int schedule_column_fknum;
	private String schedule_column_attempt;
	private String schedule_column_written_registration;
	private String schedule_column_written_test;
	private String schedule_column_written_pass;
	private String schedule_column_practical_registration;
	private String schedule_column_practical_test;
	private String schedule_column_interview_registration;
	private String schedule_column_interview_test;
	private String schedule_column_pass;
	public int getSchedule_column_num() {
		return schedule_column_num;
	}
	public void setSchedule_column_num(int schedule_column_num) {
		this.schedule_column_num = schedule_column_num;
	}
	public int getSchedule_column_fknum() {
		return schedule_column_fknum;
	}
	public void setSchedule_column_fknum(int schedule_column_fknum) {
		this.schedule_column_fknum = schedule_column_fknum;
	}
	public String getSchedule_column_attempt() {
		return schedule_column_attempt;
	}
	public void setSchedule_column_attempt(String schedule_column_attempt) {
		this.schedule_column_attempt = schedule_column_attempt;
	}
	public String getSchedule_column_written_registration() {
		return schedule_column_written_registration;
	}
	public void setSchedule_column_written_registration(String schedule_column_written_registration) {
		this.schedule_column_written_registration = schedule_column_written_registration;
	}
	public String getSchedule_column_written_test() {
		return schedule_column_written_test;
	}
	public void setSchedule_column_written_test(String schedule_column_written_test) {
		this.schedule_column_written_test = schedule_column_written_test;
	}
	public String getSchedule_column_written_pass() {
		return schedule_column_written_pass;
	}
	public void setSchedule_column_written_pass(String schedule_column_written_pass) {
		this.schedule_column_written_pass = schedule_column_written_pass;
	}
	public String getSchedule_column_practical_registration() {
		return schedule_column_practical_registration;
	}
	public void setSchedule_column_practical_registration(String schedule_column_practical_registration) {
		this.schedule_column_practical_registration = schedule_column_practical_registration;
	}
	public String getSchedule_column_practical_test() {
		return schedule_column_practical_test;
	}
	public void setSchedule_column_practical_test(String schedule_column_practical_test) {
		this.schedule_column_practical_test = schedule_column_practical_test;
	}
	public String getSchedule_column_interview_registration() {
		return schedule_column_interview_registration;
	}
	public void setSchedule_column_interview_registration(String schedule_column_interview_registration) {
		this.schedule_column_interview_registration = schedule_column_interview_registration;
	}
	public String getSchedule_column_interview_test() {
		return schedule_column_interview_test;
	}
	public void setSchedule_column_interview_test(String schedule_column_interview_test) {
		this.schedule_column_interview_test = schedule_column_interview_test;
	}
	public String getSchedule_column_pass() {
		return schedule_column_pass;
	}
	public void setSchedule_column_pass(String schedule_column_pass) {
		this.schedule_column_pass = schedule_column_pass;
	}
	
	
	
}
