package project;

public class Board_fileuploadBean {
	private String board_fileupload_name;
	private int fileupload_board_num;
	private String board_fileupload_server_name;
	private String board_fileupload_extension;
	private String board_fileupload_path;
	private int board_fileupload_size;
	
	public String getBoard_fileupload_name() {
		return board_fileupload_name;
	}
	public void setBoard_fileupload_name(String board_fileupload_name) {
		this.board_fileupload_name = board_fileupload_name;
	}
	public int getFileupload_board_num() {
		return fileupload_board_num;
	}
	public void setFileupload_board_num(int fileupload_board_num) {
		this.fileupload_board_num = fileupload_board_num;
	}
	public String getBoard_fileupload_server_name() {
		return board_fileupload_server_name;
	}
	public void setBoard_fileupload_server_name(String board_fileupload_server_name) {
		this.board_fileupload_server_name = board_fileupload_server_name;
	}
	public String getBoard_fileupload_extension() {
		return board_fileupload_extension;
	}
	public void setBoard_fileupload_extension(String board_fileupload_extension) {
		this.board_fileupload_extension = board_fileupload_extension;
	}
	public String getBoard_fileupload_path() {
		return board_fileupload_path;
	}
	public void setBoard_fileupload_path(String board_fileupload_path) {
		this.board_fileupload_path = board_fileupload_path;
	}
	public int getBoard_fileupload_size() {
		return board_fileupload_size;
	}
	public void setBoard_fileupload_size(int board_fileupload_size) {
		this.board_fileupload_size = board_fileupload_size;
	}
	
	
}
