package project;

public class WrongBean {
	private int wrong_num;
	private int wrong_choice_num;
	private String wrong_user_id;
	public int getWrong_num() {
		return wrong_num;
	}
	public void setWrong_num(int wrong_num) {
		this.wrong_num = wrong_num;
	}
	public int getWrong_choice_num() {
		return wrong_choice_num;
	}
	public void setWrong_choice_num(int wrong_choice_num) {
		this.wrong_choice_num = wrong_choice_num;
	}
	public String getWrong_user_id() {
		return wrong_user_id;
	}
	public void setWrong_user_id(String wrong_user_id) {
		this.wrong_user_id = wrong_user_id;
	}
}
