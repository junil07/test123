package project;

public class ScheduleBean {
	
	private int schedule_num;
	private String schedule_name;
	
	public int getSchedule_num() {
		return schedule_num;
	}
	
	public void setSchedule_num(int schedule_num) {
		this.schedule_num = schedule_num;
	}
	
	public String getSchedule_name() {
		return schedule_name;
	}
	
	public void setSchedule_name(String schedule_name) {
		this.schedule_name = schedule_name;
	}
	
}
