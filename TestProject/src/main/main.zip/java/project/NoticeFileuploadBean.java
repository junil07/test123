package project;

public class NoticeFileuploadBean {


	private String notice_fileupload_server_name;
	private int fileupload_notice_num;
	private String notice_fileupload_name;
	private String notice_fileupload_extension;
	private int notice_fileupload_size;
	
	
	public String getNotice_fileupload_server_name() {
		return notice_fileupload_server_name;
	}
	public void setNotice_fileupload_server_name(String notice_fileupload_server_name) {
		this.notice_fileupload_server_name = notice_fileupload_server_name;

	}
	public int getFileupload_notice_num() {
		return fileupload_notice_num;
	}
	public void setFileupload_notice_num(int fileupload_notice_num) {
		this.fileupload_notice_num = fileupload_notice_num;
	}


	public String getNotice_fileupload_name() {
		return notice_fileupload_name;
	}
	public void setNotice_fileupload_name(String notice_fileupload_name) {
		this.notice_fileupload_name = notice_fileupload_name;

	}
	public String getNotice_fileupload_extension() {
		return notice_fileupload_extension;
	}
	public void setNotice_fileupload_extension(String notice_fileupload_extension) {
		this.notice_fileupload_extension = notice_fileupload_extension;
	}

	public int getNotice_fileupload_size() {
		return notice_fileupload_size;
	}
	public void setNotice_fileupload_size(int notice_fileupload_size) {
		this.notice_fileupload_size = notice_fileupload_size;
	}

}
