/**
 * 
 */

function showPopup() { 
	window.open("popup/pwdUpdate.jsp", "a", "width=540, height=490, left=750, top=300");
}

function namePopup() {
	window.open("popup/nameUpdate.jsp", "a", "width=540, height=390, left=750, top=300");
}

function phonePopup() {
	window.open("popup/phoneUpdate.jsp", "a", "width=540, height=490, left=750, top=300");
}

function emailPopup() {
	window.open("popup/emailUpdate.jsp", "a", "width=540, height=490, left=750, top=300");
}