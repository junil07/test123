package project;

public class BuyListBean {
	
	private int buylist_num, buylist_pay, buylist_paypost_num;
	private String buylist_date, buylist_buyer, buylist_seller;
	public int getBuylist_num() {
		return buylist_num;
	}
	public void setBuylist_num(int buylist_num) {
		this.buylist_num = buylist_num;
	}
	public int getBuylist_pay() {
		return buylist_pay;
	}
	public void setBuylist_pay(int buylist_pay) {
		this.buylist_pay = buylist_pay;
	}
	public int getBuylist_paypost_num() {
		return buylist_paypost_num;
	}
	public void setBuylist_paypost_num(int buylist_paypost_num) {
		this.buylist_paypost_num = buylist_paypost_num;
	}
	public String getBuylist_date() {
		return buylist_date;
	}
	public void setBuylist_date(String buylist_date) {
		this.buylist_date = buylist_date;
	}
	public String getBuylist_buyer() {
		return buylist_buyer;
	}
	public void setBuylist_buyer(String buylist_buyer) {
		this.buylist_buyer = buylist_buyer;
	}
	public String getBuylist_seller() {
		return buylist_seller;
	}
	public void setBuylist_seller(String buylist_seller) {
		this.buylist_seller = buylist_seller;
	}
	
	
	
}
