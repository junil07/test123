package project;

public class QuestionBean {
	private int question_num;
	private String question_test_num;
	private int question_number;
	private String question_contnet;
	private int question_correct;
	private String question_file;
	private int question_filesize;
	private double question_percent;
	
	public int getQuestion_num() {
		return question_num;
	}
	public void setQuestion_num(int question_num) {
		this.question_num = question_num;
	}
	public String getQuestion_test_num() {
		return question_test_num;
	}
	public void setQuestion_test_num(String question_test_num) {
		this.question_test_num = question_test_num;
	}
	public int getQuestion_number() {
		return question_number;
	}
	public void setQuestion_number(int question_number) {
		this.question_number = question_number;
	}
	public String getQuestion_contnet() {
		return question_contnet;
	}
	public void setQuestion_contnet(String question_contnet) {
		this.question_contnet = question_contnet;
	}
	public int getQuestion_correct() {
		return question_correct;
	}
	public void setQuestion_correct(int question_correct) {
		this.question_correct = question_correct;
	}
	public String getQuestion_file() {
		return question_file;
	}
	public void setQuestion_file(String question_file) {
		this.question_file = question_file;
	}
	public int getQuestion_filesize() {
		return question_filesize;
	}
	public void setQuestion_filesize(int question_filesize) {
		this.question_filesize = question_filesize;
	}
	public double getQuestion_percent() {
		return question_percent;
	}
	public void setQuestion_percent(double question_percent) {
		this.question_percent = question_percent;
	}
}
