package project;

public class BuyListMgr {
	
	private DBConnectionMgr pool;
	
	public BuyListMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	
	
}
